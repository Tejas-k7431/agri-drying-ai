# Model research plan

No trained model is included or claimed yet.

## Candidate tasks
1. Moisture estimation: regression model (baseline linear regression, then random forest/gradient boosting).
2. Colour change: predict CIELAB L*, a*, b* and/or ΔE from controlled images and process measurements.
3. Drying-stage classification: early / mid / near-end, using validated reference labels.
4. Optional image segmentation: only after enough labelled images are available.

## Ground truth and validation
- Air temperature and relative humidity are not direct produce-moisture measurements.
- Label moisture estimates using a documented reference method and supervisor guidance.
- Split data by complete drying runs/batches to reduce data leakage.
- Report MAE/RMSE for regression and macro-F1/confusion matrix for classification.
- Record crop, sensor placement, camera settings, lighting, model version and limitations.
