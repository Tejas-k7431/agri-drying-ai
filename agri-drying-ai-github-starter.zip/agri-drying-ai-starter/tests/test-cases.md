# Initial test checklist

- [ ] Confirm sensor pin labels and supply voltage from the module documentation.
- [ ] Confirm ESP32 board and serial port in Arduino IDE.
- [ ] Check that Serial Monitor is set to 115200 baud.
- [ ] Confirm temperature and RH values are numeric and plausible.
- [ ] Disconnect/reconnect sensor and verify error handling.
- [ ] Compare readings with a reference instrument, documenting conditions.
- [ ] Verify timestamps and run/tray labels before collecting experimental data.
- [ ] Do not claim accuracy until repeated measurements have been analysed.
