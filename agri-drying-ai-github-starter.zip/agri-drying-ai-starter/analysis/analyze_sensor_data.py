import pandas as pd
import matplotlib.pyplot as plt

# Run from the repository root: python analysis/analyze_sensor_data.py
path = "data/sample_readings.csv"
df = pd.read_csv(path)

print("Rows:", len(df))
print(df.describe(include="all"))
print("\nNOTE: The bundled rows are illustrative, not real experimental measurements.")

if {"temperature_c", "relative_humidity_pct"}.issubset(df.columns):
    ax = df[["temperature_c", "relative_humidity_pct"]].astype(float).plot(
        subplots=True, marker="o", title=["Temperature (°C)", "Relative humidity (%)"]
    )
    plt.tight_layout()
    plt.show()
