/*
  Agri Drying AI — Module 1: ESP32 environmental sensing
  Example wiring for a DHT22 module:
    VCC -> 3V3 (check your module specifications)
    GND -> GND
    DATA -> GPIO 4
  This is starter code. Test your specific sensor/module before deployment.
*/
#include <DHT.h>

#define DHTPIN 4
#define DHTTYPE DHT22

DHT dht(DHTPIN, DHTTYPE);
unsigned long lastReadMs = 0;
const unsigned long READ_INTERVAL_MS = 5000;

void setup() {
  Serial.begin(115200);
  delay(500);
  dht.begin();
  Serial.println("elapsed_ms,temperature_c,relative_humidity_pct,status");
}

void loop() {
  const unsigned long now = millis();
  if (now - lastReadMs < READ_INTERVAL_MS) return;
  lastReadMs = now;

  const float humidity = dht.readHumidity();
  const float temperature = dht.readTemperature();

  if (isnan(humidity) || isnan(temperature)) {
    Serial.print(now);
    Serial.println(",,,READ_ERROR");
    return;
  }

  // Basic sanity check; refine limits for the actual sensor and dryer.
  if (humidity < 0.0 || humidity > 100.0 || temperature < -40.0 || temperature > 80.0) {
    Serial.print(now);
    Serial.println(",,,OUT_OF_RANGE");
    return;
  }

  Serial.print(now);
  Serial.print(",");
  Serial.print(temperature, 2);
  Serial.print(",");
  Serial.print(humidity, 2);
  Serial.println(",OK");
}
