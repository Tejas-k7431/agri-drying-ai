# Module 1 wiring notes — ESP32 + DHT22

| DHT22 module pin | ESP32 DevKit connection |
|---|---|
| VCC / + | 3V3, if supported by the module |
| GND / - | GND |
| DATA / OUT | GPIO 4 |

Notes:
- Pin order differs between bare DHT22 sensors and breakout modules; check the exact module labels/datasheet.
- Some bare DHT22 sensors need a pull-up resistor on DATA; many breakout modules already include one.
- Use a suitable USB data cable to power/program the ESP32.
- Keep the board outside the hot and humid chamber.
- Do not connect a fan directly to a GPIO. Add a correctly rated driver circuit in a later, separately tested module.
- Temperature/RH measure the air, not the internal moisture content of the produce.
