# Agri Drying AI

**Project:** IoT and AI-Based Agricultural Produce Drying, Moisture and Colour-Quality Monitoring System

## Project status
This repository contains project planning and starter materials. Hardware integration, sensor measurements and model performance must be verified experimentally before being described as completed results.

## Objectives
- Monitor drying-air temperature and relative humidity.
- Add tray mass tracking and energy monitoring in later phases.
- Capture standardised RGB images to analyse colour/discolouration.
- Build a labelled dataset using reference moisture measurements.
- Evaluate machine-learning models for moisture estimation, colour change and drying-stage prediction.

## Planned architecture
Sensors → ESP32 → local CSV/SD logging → Wi-Fi (optional) → dashboard/edge computer → analysis and AI models.

## Current module
**Module 1: ESP32 environmental sensing.** Read temperature and relative humidity, validate sensor values and emit timestamped CSV-style records to the Serial Monitor.

## Hardware safety
- Keep the ESP32 and other electronics outside the hot/humid drying chamber.
- Never drive a fan directly from an ESP32 GPIO pin.
- Use a correctly rated MOSFET/relay driver and suitable low-voltage supply.
- Do not connect mains AC wiring unless supervised by a qualified person.
- Temperature/RH are environmental readings; they are not direct measurements of moisture inside produce.

## Folder guide
- `docs/`: research review, project presentation and wiring diagram.
- `hardware/`: ESP32 starter firmware and wiring notes.
- `data/`: sample CSV schema (illustrative data only).
- `analysis/`: starter analysis script.
- `models/`: model research plan; no trained model is claimed yet.
- `tests/`: initial validation checklist.

## First build
1. Install Arduino IDE.
2. Install the `DHT sensor library` and `Adafruit Unified Sensor` library.
3. Select the correct ESP32 board and port.
4. Connect a DHT22 module to the ESP32 as described in `hardware/wiring-notes.md`.
5. Upload `hardware/esp32_sensor_reading.ino` and open Serial Monitor at 115200 baud.
6. Verify readings against a trusted reference before collecting project data.

## Research documents
See `docs/research-review.pdf` and `docs/project-presentation.pptx`.
